#include "stm32f10x.h"                  // Device header
#include "Delay.h"

volatile uint16_t US_Num;
volatile uint8_t  US_Ready;
uint8_t  Dis, Num;
uint16_t TrigTimer;



void HCSR04_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode =  GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	GPIO_WriteBit(GPIOB, GPIO_Pin_0, Bit_RESET);

}




void Trig_OutUp_15us(void)
{
	GPIO_WriteBit(GPIOB, GPIO_Pin_0, Bit_SET);
	Delay_us(15);
	GPIO_WriteBit(GPIOB, GPIO_Pin_0, Bit_RESET);
}














