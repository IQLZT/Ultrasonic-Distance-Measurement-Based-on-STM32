#ifndef  __HCSR04_H_
#define  __HCSR04_H_


void HCSR04_Init(void);
void Trig_OutUp_15us(void);



extern volatile uint16_t US_Num;
extern  volatile uint8_t  US_Ready;
extern uint8_t  Dis, Num;
extern uint16_t TrigTimer;







#endif

