#include "stm32f10x.h"                  // Device header

void Servo_Init(void)
{
	RCC_APB2PeriphClockCmd( RCC_APB2Periph_TIM1, ENABLE );
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode =  GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
		
	
	TIM_InternalClockConfig(TIM1);
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseInitStruct;
	TIM_TimeBaseInitStruct.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseInitStruct.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInitStruct.TIM_Period = 20000 - 1;
	TIM_TimeBaseInitStruct.TIM_Prescaler = 72 - 1;
	TIM_TimeBaseInitStruct.TIM_RepetitionCounter = 0;
		TIM_TimeBaseInit(TIM1, &TIM_TimeBaseInitStruct);
	
	//����Ƚ�
	
	
	 TIM_OCInitTypeDef  TIM_OCInitStructure;
	TIM_OCStructInit( &TIM_OCInitStructure); 
	 
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;  
	TIM_OCInitStructure.TIM_OutputState = ENABLE ;
	TIM_OCInitStructure.TIM_Pulse =1500;  
	
		TIM_OC4Init(TIM1, &TIM_OCInitStructure);  //����Ƚ�ʵ��ѡ��ͨ���ĵط�
	
	TIM_ITConfig(TIM1, TIM_IT_Update, ENABLE );
	
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel                   =  TIM1_UP_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd                = ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority        = 0;
	NVIC_Init(&NVIC_InitStructure);
	

	
	TIM_CtrlPWMOutputs(TIM1, ENABLE );   //�߼���ʱ��ʹ�ܱ���ӵ�һ��
	TIM_Cmd(TIM1, ENABLE);
	
	 TIM_ClearFlag(TIM1, TIM_FLAG_Update);
}


//  TIM_SetCompare1(TIM1, uint16_t Compare1);



