#ifndef  __Time_H_
#define  __Time_H_

void Time_Init(void);






#endif


