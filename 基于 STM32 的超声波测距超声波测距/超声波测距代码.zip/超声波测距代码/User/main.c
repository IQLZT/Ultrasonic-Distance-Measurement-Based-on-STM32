#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "HC-SR04.h"
#include "Time.h"


void Time_Init(void);
static uint16_t Capture_Rise;
uint16_t frame_cnt = 0;          /* 帧计数器，用于确认程序在运行 */


int main(void)
{
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    OLED_Init();
    Time_Init();
    HCSR04_Init();


    while (1)
    {

        /*
         * 步骤 1: 发 Trig 脉冲，然后阻塞等 60ms
         * HC-SR04 测量周期约 60ms，阻塞是最稳的方式
         */
        Trig_OutUp_15us();          /* PB0 发 15us 高脉冲 */
        Delay_ms(60);               /* 等回波返回          */

        /*
         * 步骤 2: 检查有没有新的测量结果
         */
        if (US_Ready)
        {
            US_Ready = 0;

            /*
             * 有效范围: 58(3cm) ~ 23200(400cm)
             * US_Num 单位: 微秒
             */
            if (US_Num >= 58 && US_Num <= 23200)
            {
                Dis = US_Num / 58;      /* us → cm */
            }
            else
            {
                Dis = 200;              /* 超时/异常 → 显示 200 作为标识 */
            }
        }
        else
        {
            /*
             * 没收到回波 → 显示 255 表示"无回波"
             * 这样你就能区分"有回波但异常"和"根本没回波"
             */
            Dis = 255;
        }

        /*
         * 步骤 3: OLED 显示
         * 第 1 行: 距离(cm) + 帧计数(确认程序在跑)
         * 第 2 行: 原始 US_Num 值(调试用)
         */
        frame_cnt++;
        OLED_ShowNum(1, 1, Dis,        6);   /* Dis 值   */
        OLED_ShowNum(1, 8, frame_cnt,  8);   /* 帧计数器  */
        OLED_ShowNum(2, 1, US_Num,     8);   /* 原始 US_Num */

    }


}


/*
 * TIM3 CC1 输入捕获中断
 * Echo 脚 (PA6) 的上升沿/下降沿交替捕获
 */
void TIM3_IRQHandler(void)
{
    if (TIM_GetITStatus(TIM3, TIM_IT_CC1) != RESET)
    {
        uint16_t capture_val = TIM_GetCapture1(TIM3);
        TIM_ClearITPendingBit(TIM3, TIM_IT_CC1);

        /*
         * CC1P=1 → 刚捕获的是下降沿（脉冲结束）
         * CC1P=0 → 刚捕获的是上升沿（脉冲开始）
         */
        if (TIM3->CCER & TIM_CCER_CC1P)
        {
            /* 下降沿 → 计算脉宽 */
            if (capture_val >= Capture_Rise)
            {
                US_Num = capture_val - Capture_Rise;
            }
            else
            {
                US_Num = (65536 - Capture_Rise) + capture_val;
            }
            US_Ready = 1;

            /* 下次捕获上升沿 */
            TIM3->CCER &= ~TIM_CCER_CC1P;
        }
        else
        {
            /* 上升沿 → 记录起始值 */
            Capture_Rise = capture_val;

            /* 下次捕获下降沿 */
            TIM3->CCER |= TIM_CCER_CC1P;
        }
    }
}
